import random
ranint = random.randint(1, 5)
ranintfile = open("ranint.txt", "w")
ranintfile.write(str (ranint))
ranintfile.close()

