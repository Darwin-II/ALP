for count in {1..256}
do
    rm -rf stanfuns$count.txt
done
