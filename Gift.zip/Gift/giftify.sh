rm -rf *.cpp
rm -rf *.cpp~

