for count in {1..256}
do
	rm -rf fun$count.cp
	rm -rf fun$count
done
