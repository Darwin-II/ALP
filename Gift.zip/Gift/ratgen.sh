for count in {1..100}
do
	echo 2 >> rationale.txt
done
