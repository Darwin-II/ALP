import random
ranint = random.randint(0, 255)
ranintfile = open("ranint.txt", "w")
ranintfile.write(str (ranint))
ranintfile.close()

