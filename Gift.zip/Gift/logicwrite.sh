for count in {1..256}
do
    python stanfundesign.py
    mv island.txt stanfuns$count.txt
done
./logicflow.out
