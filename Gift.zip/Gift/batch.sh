for count in {1..6}
do
    zapcc -lstdc++ stanfun$count.cpp -o stanfun$count.out
done
