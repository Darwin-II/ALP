for count in {1..4}
do
    echo "#include <iostream>" >> stanfun$count.cpp
    echo "#include <fstream>" >> stanfun$count.cpp
    echo "using namespace std;" >> stanfun$count.cpp
    echo "int count;" >> stanfun$count.cpp
    echo "int despos[3];" >> stanfun$count.cpp
    echo "int desint[2];" >> stanfun$count.cpp
    echo "int rationalear[10001];" >> stanfun$count.cpp
    echo "string island;" >> stanfun$count.cpp
    echo "int islandII;" >> stanfun$count.cpp
    echo "int respos;" >> stanfun$count.cpp
    echo "int main () {" >> stanfun$count.cpp
    echo "  ifstream desposes;" >> stanfun$count.cpp
    echo "  ifstream resposfile;" >> stanfun$count.cpp
    echo "  fstream rationale;" >> stanfun$count.cpp
    echo "  desposes.open(desposes.txt);" >> stanfun$count.cpp
    echo "  rationale.open(rationale.txt);" >> stanfun$count.cpp
    echo "  resposfile.open(respos.txt);" >> stanfun$count.cpp
    echo "  getline (resposfile, island);" >> stanfun$count.cpp
    echo "  respos = stoi(island);" >> stanfun$count.cpp
    echo "  for (count = 1; count < 3; count++) {" >> stanfun$count.cpp
    echo "    getline (desposes, island);" >> stanfun$count.cpp
    echo "    despos[count] = stoi(island);" >> stanfun$count.cpp
    echo "  }" >> stanfun$count.cpp
    echo "  resposfile.close();" >> stanfun$count.cpp
    echo "  desposes.close();" >> stanfun$count.cpp
    echo "  for (count = 1; count < 10001; count++) {" >> stanfun$count.cpp
    echo "    getline (rationale, island);" >> stanfun$count.cpp
    echo "    if (count == despos[1]) {" >> stanfun$count.cpp
    echo "      desint[0] = stoi(island);" >> stanfun$count.cpp
    echo "    }" >> stanfun$count.cpp
    echo "    if (count == despos[2]) {" >> stanfun$count.cpp
    echo "      desint[1] = stoi(island);" >> stanfun$count.cpp
    echo "    }" >> stanfun$count.cpp
    echo "    rationalear[count] = stoi(island);" >> stanfun$count.cpp
    echo "  }" >> stanfun$count.cpp
    echo "  rationalear[respos] = desint[0] + desint[1];" >> stanfun$count.cpp
    echo "  rationale.open(rationale.txt);" >> stanfun$count.cpp
    echo "  for (count =1; count < 10001; count++) {" >> stanfun$count.cpp
    echo "  rationale << rationalear[count] << endl;" >> stanfun$count.cpp
    echo "  }" >> stanfun$count.cpp
    echo "  rationale.close();" >> stanfun$count.cpp
    echo "  return 0;" >> stanfun$count.cpp
    echo "}" >> stanfun$count.cpp
done
