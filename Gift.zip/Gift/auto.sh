for count in {1..256}
do
    echo "#include <iostream>" >> fun$count.cpp 
    echo "#include <fstream>" >> fun$count.cpp
    echo "using namespace std;" >> fun$count.cpp
    echo "int count;" >> fun$count.cpp
    echo "int stanfun[6];" >> fun$count.cpp
    echo "string island;" >> fun$count.cpp
    echo "int main () {" >> fun$count.cpp
    echo " ifstream stanfunfile;" >> fun$count.cpp
    echo " ofstream tempscript;" >> fun$count.cpp
    echo " stanfunfile.open("\"stanfuns$count.txt"\");" >> fun$count.cpp
    echo " tempscript.open(""\"tempscript.sh""\");" >> fun$count.cpp
    echo " for (count = 1; count < 6; count++) {" >> fun$count.cpp
    echo "   getline (stanfunfile, island);" >> fun$count.cpp
    echo "   stanfun[count] = stoi(island);" >> fun$count.cpp
    echo " }" >> fun$count.cpp
    echo " for (count = 1; count < 6; count++){" >> fun$count.cpp
    echo "   tempscript << ""\"clisp "\"";" >> fun$count.cpp
    echo "   tempscript << ""\"stanfun""\";" >> fun$count.cpp
    echo "   tempscript << stanfun[count];" >> fun$count.cpp
    echo "   tempscript << ""\".lisp""\";" >> fun$count.cpp
    echo "   tempscript << endl;" >> fun$count.cpp
    echo " }" >> fun$count.cpp
    echo " system (""\"./tempscript.sh""\");" >> fun$count.cpp
    echo " return 0;" >> fun$count.cpp
    echo "}" >> fun$count.cpp
    g++ fun$count.cpp -o fun$count.out
done
