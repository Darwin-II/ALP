for count in {1..256}
do
	echo $count > rationale.txt
	echo "\n" > rationale.txt
done
