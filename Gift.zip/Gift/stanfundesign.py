import random
ranintfile = open("island.txt", "w")
for count in range(1, 6):
	ranint = random.randint(1,6)
	ranintfile.write(str (ranint))
	ranintfile.write("\n")
ranintfile.close()
