import random
ranintparamfile = open("ranintparam.txt", "r")
island = ranintparamfile.read()
ranintparam = int(island)
ranint = random.randint(1, ranintparam)
ranintparamfile.close()
ranintfile = open("ranint.txt", "w")
ranintfile.write(str (ranint))
ranintfile.close()

